# Ansible Role: ansible-role_rhos_add_worker

<!-- TOC -->

- [Ansible Role: ansible-role_rhos_add_worker](#ansible-role--cookiecutterrole_name-)
    - [Jenkins Build Details](#jenkins-build-details)
    - [ansible-role_rhos_add_worker - Description](#-cookiecutterrole_name----description)
    - [ansible-role_rhos_add_worker - Requirements](#-cookiecutterrole_name----requirements)
    - [Using the ansible-rhos_add_worker role within an Ansible Playbook](#using-the--cookiecutterplaybook_name--role-within-an-ansible-playbook)
        - [Example Ansible Playbook using ansible-role_rhos_add_worker role](#example-ansible-playbook-using--cookiecutterrole_name--role)
        - [IMPORTANT STEP](#important-step)
    - [Default Variables](#default-variables)
    - [Custom Variables](#custom-variables)
    - [Inventory Variables](#inventory-variables)
    - [Local development testing](#local-development-testing)
        - [Pre-Requisites](#pre-requisites)
    - [Local Development Testing using Molecule](#local-development-testing-using-molecule)
        - [Installing Molecule](#installing-molecule)
        - [How to run a molecule lint on a rhos role](#how-to-run-a-molecule-lint-on-a-cookiecuttertarget_test_platform-role)
    - [Documentation](#documentation)
        - [Ansible Galaxy Role failing to install](#ansible-galaxy-role-failing-to-install)
        - [Molecule create fails on "create" step](#molecule-create-fails-on-create-step)
    - [Monitoring](#monitoring)
    - [Contributing](#contributing)
    - [History](#history)
    - [Credits](#credits)

<!-- /TOC -->

## Jenkins Build Details

Master Branch

[![Build Status](https://jenkins.sni.com.mx/buildStatus/icon?job=ansible/ansible-role_rhos_add_worker/master)](https://jenkins.sni.com.mx/view/ITO/job/ansible/job/ansible-role_rhos_add_worker/job/master/)

Develop Branch

[![Build Status](https://jenkins.sni.com.mx/buildStatus/icon?job=ansible/ansible-role_rhos_add_worker/develop)](https://jenkins.sni.com.mx/view/ITO/job/ansible/job/ansible-role_rhos_add_worker/job/develop/)

[https://jenkins.sni.com.mx/view/ITO/job/ansible/job/ansible-role_rhos_add_worker/](https://jenkins.sni.com.mx/view/ITO/job/ansible/job/ansible-role_rhos_add_worker/)

## ansible-role_rhos_add_worker - Description

This ansible role builds a list of vsphere VMs as worker nodes for OpenShift.

## ansible-role_rhos_add_worker - Requirements

rhos

## Using the ansible-rhos_add_worker role within an Ansible Playbook

### Required vars
| Variable | Description |
|----------|-------------|
| worker_count | The total desired number infra worker nodes |
| worker_type | This value is either 'worker' or 'infra', and changes how the VM is built and how the node tagged/labeled |

### Example Ansible Playbook using ansible-role_rhos_add_worker role

```bash
---

- hosts: "{{ selected_hosts }}"
  connection: local
  gather_facts: no
  roles:
    - ansible-role_rhos_add_worker

```

### IMPORTANT STEP

If you want to install the csc ansible-role via the `ansible-galaxy` command
you'll need to create a [requirements.yml](roles/requirements.yml)
file in "roles/" directory (if one doesn't already exist),
with the following contents:

```bash
---
- name: ansible-role_rhos_add_worker
  src: https://sni.com.mx/INFRA/ansible-role_rhos_add_worker
  scm: git
```

...and install role(s) using the following command from parent directory:

`ansible-galaxy install -p roles -r roles/requirements.yml`

## Default Variables

See [`defaults/main.yml`](defaults/main.yml).

Default Variables listed below:

| Variable | Description |
| --- | --- |
| variable | value |

## Custom Variables

See [`vars/main.yml`](vars/main.yml).

Custom Variables listed below:

| Variable | Description |
| --- | --- |
| variable | value |
See [`vars/artifactory_encrypted_vars.yml`](vars/artifactory_encrypted_vars.yml.yml).

| Variable | Description |
| --- | --- |
| artifactory_user |  |
| artifactory_pass |  |
| artifactory_url| This doesn't really need to be encyrpted, but placed in this vars file for artifactory one stop. 'https://artifactory2.sni.com.mx/artifactory/cherwell-db-exports/'  Simply appened your file name when using this variable to store/retrieve files in the repo for network |

## Inventory Variables

**REQUIRED:** These variables would be defined in inventory file as host varables.

| Variable | Description |
| --- | --- |
| variable | value |

## Local development testing

### Pre-Requisites

The following components are required for executing this playbook on local desktop

1. [Ansible 2.9.6+](http://docs.ansible.com/ansible/latest/intro_installation.html)
2. [Git 2.11+](https://git-scm.com/downloads)
3. [Python 2.7+](https://www.python.org/downloads/)
4. [Python Package Index (PIP) 9.0.1+](https://pip.pypa.io/en/stable/installing/)
5. [Molecule 2.7.0](https://molecule.readthedocs.io/en/latest/installation.html)

Refer to following link for Windows Desktop Config
[https://sni.com.mx/INFRA/infra-devops-windows-desktop-conf](https://sni.com.mx/INFRA/infra-devops-windows-desktop-conf)

Refer to following link for MAC OSX Config
[https://sni.com.mx/INFRA/infra-devops-macos-desktop-conf](https://sni.com.mx/INFRA/infra-devops-macos-desktop-conf)

## Local Development Testing using Molecule

>"Molecule is designed to aid in the development and testing of Ansible roles.
>Molecule provides support for testing with multiple instances, operating systems
>and distributions, virtualization providers, test frameworks and testing scenarios.
>Molecule is opinionated in order to encourage an approach that results in
>consistently developed roles that are well-written, easily understood and maintained."

Network support is really limited in molecule, so molecule lint is the only practical function from your local machine.

[http://molecule.readthedocs.io/en/latest/index.html](http://molecule.readthedocs.io/en/latest/index.html)

### Installing Molecule

Run the following command to install all python packages required for molecule testing

```bash
sudo pip install -r test/pip-requirements.txt --upgrade-strategy only-if-needed
```

the following packages will be installed as they are required for
both Linux and Windows testing of Ansible:

- molecule 2.12.0+ - Molecule aids in the development and testing of Ansible roles.
- ansible 2.9.6+ - Radically simple IT automation
- xmltodict 0.11.0+ - Makes working with XML feel like you are working with JSON
- pywinrm 0.3.0+ - Python library for Windows Remote Management

see http://molecule.readthedocs.io/en/latest/installation.html for additional details.


Prior to any test run, perform steps below:

1. Open a terminal session on your local machine and clone GitHub repo:
    `git clone https://sni.com.mx/INFRA/ansible-role_rhos_add_worker`
2. Change repo directory:
    `cd ansible-role_rhos_add_worker`

### How to run a molecule lint on a rhos role

`molecule lint -s rhos`

## Documentation

For best practices using the various technologies,
please visit ICAA team documentation site:
https://sni.com.mx/INFRA/documentation

### Ansible Galaxy Role failing to install

...if you see the following error when running the
`ansible-galaxy install -p roles -r roles/requirements.yml` command:

```diff

$ ansible-galaxy install -p roles -r roles/requirements.yml

+ [WARNING]: - ansible-role_was NOT installed successfully:
+ this role does not appear to have a meta/main.yml file.

- ERROR! - you can use --ignore-errors to skip failed roles
- and finish processing the list.

```

...then make sure the `meta/main.yml` exists in the custom role.

### Molecule create fails on "create" step

If molecule fails to create the virtualbox vm,
first - make sure you've followed the instructions listed here:
[Add CSC compliant vagrant box for virtualbox](#add-csc-compliant-vagrant-box-for-virtualbox)

Otherwise, you may need to force an update of the
version of the vagrant box using the following command:
`vagrant box update --box rhos`

## Monitoring

If there are any monitoring considerations as part of
running this role, please include in this section.

## Contributing

See [CONTRIBUTING](CONTRIBUTING.md)

## History

See [CHANGELOG](CHANGELOG.md)

## Credits

See [AUTHORS](AUTHORS.md)

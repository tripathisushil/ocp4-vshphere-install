# Ansible Role: ansible-role_setup_base_cluster_nodes

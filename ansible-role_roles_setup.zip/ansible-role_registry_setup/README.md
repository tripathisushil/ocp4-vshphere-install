# Ansible Role: ansible-role_registry_setup

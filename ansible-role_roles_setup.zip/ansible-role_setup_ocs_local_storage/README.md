# Ansible Role: ansible-role_setup_ocs_local_storage

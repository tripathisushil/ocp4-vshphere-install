# Ansible Role: ansible-role_install_oc

# Ansible Role: ansible-role_cluster_logging

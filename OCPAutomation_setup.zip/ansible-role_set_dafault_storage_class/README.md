# Ansible Role: ansible-role_set_dafault_storage_class

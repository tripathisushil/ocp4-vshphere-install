# Ansible Role: ansible-role_rhos_worker_setup

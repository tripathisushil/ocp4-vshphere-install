# Ansible Playbook: ansible-registry_setup

# Ansible Playbook: ansible-setup_base_cluster_nodes

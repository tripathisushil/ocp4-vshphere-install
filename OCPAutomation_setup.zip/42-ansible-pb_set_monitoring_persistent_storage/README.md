# Ansible Playbook: ansible-pb_set_monitoring_persistent_storage

# Ansible Playbook: ansible-rhos_worker_setup

# Ansible Playbook: ansible-pb_set_dafault_storage_class

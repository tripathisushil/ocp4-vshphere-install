# Ansible Playbook: ansible-cluster_logging

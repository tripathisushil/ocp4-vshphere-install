# Ansible Playbook: ansible-pb_setup_ocs_local_storage

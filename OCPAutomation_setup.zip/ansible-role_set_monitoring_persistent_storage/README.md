# Ansible Role: ansible-role_set_monitoring_persistent_storage

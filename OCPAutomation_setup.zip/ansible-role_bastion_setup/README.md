# Ansible Role: ansible-role_bastion_setup
